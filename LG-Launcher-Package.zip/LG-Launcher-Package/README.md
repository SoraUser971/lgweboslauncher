# LG Launcher package

A ready-made .apk could not be built here (the sandbox has no Android SDK), so this zip
contains a complete Android Studio project that builds the APK in a few clicks, plus a
webOS version for LG TVs.

## 1. Android APK (phones, Android TV / Google TV, Fire TV)

1. Install Android Studio and open the `android-project` folder.
2. Let it sync (it downloads Gradle and the Android SDK parts it needs).
3. Menu: Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The file is at `android-project/app/build/outputs/apk/debug/app-debug.apk`.
   Command line alternative (Gradle 8.5+ installed): `gradle assembleDebug`.
5. Install it: copy it to the device, or run `adb install app-debug.apk`.

On Android TV the app shows up in the apps row, and it can also be chosen as the Home app.
Back acts like Esc in the launcher. TV tiles (YouTube, Netflix, ...) open the real installed
Android app if it is present, otherwise the website.

## 2. LG webOS TV (an APK does NOT run on LG TVs)

LG TVs run webOS and cannot install .apk files. Use the `webos-app` folder instead:

1. Install the webOS TV CLI (`npm i -g @webosose/ares-cli`) and enable Developer Mode on the TV.
2. `ares-package webos-app`   (creates com.example.lglauncher_1.0.0_all.ipk)
3. `ares-setup-device` (add your TV), then `ares-install --device tv com.example.lglauncher_1.0.0_all.ipk`
4. `ares-launch --device tv com.example.lglauncher`
